<?php
define('RAZORPAY_KEY_ID', 'rzp_test_RiPwUgNvRHiTQn');
define('RAZORPAY_KEY_SECRET', '3P73LyjGpy8rRpYxc4mDXCYB');
define('RAZORPAY_WEBHOOK_SECRET', 'set_a_random_string_here'); // e.g. bin2hex(random_bytes(16))
